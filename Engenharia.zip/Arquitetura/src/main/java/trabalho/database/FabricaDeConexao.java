package trabalho.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class FabricaDeConexao {
    
    private static Connection conexao;
    private static String url = "jdbc:mysql://localhost:3306/controle_protocolo?useTimezone=true&serverTimezone=UTC";
    private static String usuario ="root";
    private static String senha ="root";
    
    public static Connection getConexao() throws SQLException{
        if(conexao == null){
            conexao = DriverManager.getConnection(url,usuario, senha);
        }
        return conexao;
    }
}
