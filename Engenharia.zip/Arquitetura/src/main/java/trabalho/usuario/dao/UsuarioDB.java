/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho.usuario.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import trabalho.database.FabricaDeConexao;
import trabalho.usuario.datamodel.Usuario;

/**
 *
 * @author Tássio
 */
public class UsuarioDB {

    private Connection conexao;

    public UsuarioDB() throws SQLException {
        conexao = FabricaDeConexao.getConexao();
    }

    public void inserirUser(Usuario usuario) throws SQLException {
        String sql = "INSERT INTO tb_usuario"
                + " (USU_NOME, USU_SOBRENOME, USU_EMAIL, USU_SENHA, USU_DEPARTAMENTO_ID)"
                + " VALUES (?,?,?,?,?)";
        PreparedStatement ps = conexao.prepareStatement(sql);
        ps.setString(1, usuario.getNome());
        ps.setString(2, usuario.getSobreNome());
        ps.setString(3, usuario.getEmail());
        ps.setString(4, usuario.getSenha());
        ps.setInt(5, usuario.getDepartamento());
        ps.execute();
    }

    public Integer getDepartamento(String departamento) throws SQLException {
        String sql = "SELECT DEP_ID AS IDDEP FROM TB_DEPARTAMENTO WHERE DEP_DESCRICAO = ?";
        PreparedStatement ps = conexao.prepareStatement(sql);
        ps.setString(1, departamento);
        ResultSet rs = ps.executeQuery();
        rs.next();
        Integer idDEP = rs.getInt("IDDEP");

        return idDEP;
    }

}
